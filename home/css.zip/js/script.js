
document.getElementById("btn-nav").onclick = function() {
    myFunction()};

function myFunction() {
    document.getElementById("menu_box").classList.toggle("show");
}

// var nav=document.getElementById('nav');

// document.getElementById('btn-nav').onclick = function(){
//     nav.style.display="block";
//     nav.style.position="absolute";
//     nav.style.top="64px";
//     nav.style.left="0px";
//     nav.style.background="#343a40";
//     nav.style.width="100%";
    
// }
